===========================================================================
Follow these steps to generate one sample-path solution trajectory of
cgR-SPLINE on the three-stage flowline problem. This is achieved by running
top.m with an input seed vector to the oracle (problemseed) and an input 
seed vector to cgR-SPINE (solverseed). Change both seed values and re-run 
top.m to generate a new sample-path. 
===========================================================================

(1.) For efficiency we suggest generating a mex file for the oracle in MATLAB:
>> mex TSF.c
For more information, see the MATLAB reference page for building mex files.

If you are unable to build a mex file, make the following change to top.m.  
problemname      = 'ThreeStageFlowline';
This will cause cgR-SPLINE to call the oracle coded as a .m file. 


(2.) Run top.m with relevant input parameters. Open top.m for a detailed 
descriptions of all parameters.
>> top([1;2;3],[2;3;4;5])


(3.) Running top.m should generate two files
a. TSF.txt          : Logs every major algorithmic step in 
                      cgR-SPLINE. 
b. TSF_bestsols.txt : A table of all solutions returned by the SPLINE routine 
                      after every inner iteration in each restart. Restarts 
                      may repeat if a restart is unable to find a sample-
                      path feasible solution.
c. TSF_report.txt   : A table of local solutions X_r and the updated 
                      incumbents Z_r.
d. TSF_final.txt    : A table of global solution estimates (incumbents) Z_r
e. TSF_vars.mat     : Generated at the end of a sample-path run.
                      Data from _bestsols, _report, and _final is 
                      stored in TSF_vars.mat. See cgRSPLINE_v2.m for a
                      description of the TSF_vars.mat.   

(4.) Code outcome from running top.m with problemseed=[1;2;3] and 
     solverseed=[2;3;4;5] is saved in ExampleOutput.